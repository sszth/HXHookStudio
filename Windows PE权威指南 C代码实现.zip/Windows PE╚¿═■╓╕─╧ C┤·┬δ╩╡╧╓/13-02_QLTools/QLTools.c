#include <Windows.h>
#include<tlhelp32.h>
#include "resource.h"




HINSTANCE hInstance;



/*
��ȡָ�����̹���ģ���б�
*/
void _GetModuleList(HWND hModuleShowList, DWORD dwIndex)
{
	HANDLE hModuleSnapshot;
	MODULEENTRY32 process_ME;
	BOOL bModule;

	
	SendMessage(hModuleShowList, LB_RESETCONTENT, 0, 0);
	hModuleSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwIndex);
	bModule = Module32First(hModuleSnapshot, &process_ME);

	while (bModule)
	{
		if (process_ME.th32ProcessID == dwIndex)
		{
			SendMessage(hModuleShowList, LB_ADDSTRING, 0, (LPARAM)&process_ME.szExePath);
		}
		bModule = Module32Next(hModuleSnapshot, &process_ME);
	}

	CloseHandle(hModuleSnapshot);
}


/*
��ȡ�����б�
*/
void _GetProcessList(HWND hWnd, HWND hProcessListBox, HWND hModuleShowList)
{
	PROCESSENTRY32 process_PE;
	HANDLE hProcessSnapshot;
	BOOL bProcess;
	DWORD dwProcessID;
	DWORD dwIndex;





	RtlZeroMemory(&process_PE, sizeof(process_PE));
	SendMessage(hProcessListBox, LB_RESETCONTENT, 0, 0);

	process_PE.dwSize = sizeof(process_PE);
	hProcessSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	bProcess = Process32First(hProcessSnapshot, &process_PE);

	while (bProcess)
	{
		dwIndex = SendMessage(hProcessListBox, LB_ADDSTRING, 0, (LPARAM)&process_PE.szExeFile);
		SendMessage(hProcessListBox, LB_SETITEMDATA, dwIndex, process_PE.th32ProcessID);
		bProcess = Process32Next(hProcessSnapshot, &process_PE);
	}
	CloseHandle(hProcessSnapshot);

	//ѡ�е�һ��
	dwIndex = SendMessage(hProcessListBox, LB_SETCURSEL, 0, 0);
	dwProcessID = SendMessage(hProcessListBox, LB_GETITEMDATA, dwIndex, 0);
	_GetModuleList(hModuleShowList, dwProcessID);
	EnableWindow(GetDlgItem(hWnd, IDOK), FALSE);


}



/*
ִ�н������̵ĳ���
����Ϊ��ntsd
����Ϊ��-c q -p PID
*/
void _RunThread(DWORD  dwIndex)
{
	STARTUPINFO stStartUp;
	PROCESS_INFORMATION stProcInfo;

	TCHAR szProcessFileName[256];

	wsprintf(szProcessFileName, TEXT("ntsd -c q -p %u"), dwIndex);
	GetStartupInfo(&stStartUp);
	//64λϵͳ����ҪC:\Windows\SysWOW64����ntsd.exe
	//32λϵͳ����ҪC:\Windows\System32����ntsd.exe
	if (CreateProcess(NULL, szProcessFileName, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS,
		NULL, NULL, &stStartUp, &stProcInfo))
	{
		WaitForSingleObject(stProcInfo.hProcess, INFINITE);
		CloseHandle(stProcInfo.hProcess);
		CloseHandle(stProcInfo.hThread);
	}
	else
	{
		MessageBox(NULL, TEXT("����Ӧ�ó������"), NULL, MB_OK | MB_ICONERROR);
	}



}



/*
���ڳ���
*/
INT_PTR CALLBACK _ProcKillMain(HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
	HICON hIcon;
	static HWND hProcessListBox;
	static HWND hModuleShowList;
	DWORD dwProcessID;
	DWORD dwIndex;


	switch (wMsg)
	{
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_INITDIALOG:			//��ʼ��
		hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_MAIN));
		SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);

		hProcessListBox = GetDlgItem(hWnd, IDC_PROCESS);
		hModuleShowList = GetDlgItem(hWnd, IDC_PROCESS_MODEL);

		_GetProcessList(hWnd, hProcessListBox, hModuleShowList);//��ʾ���̣����ѵ�һ����̵�ӳ��ģ��Ҳ��ʾ����
		break;

	case WM_COMMAND:			
		switch (LOWORD(wParam))
		{
		case IDOK:			
			dwIndex = SendMessage(hProcessListBox, LB_GETCURSEL, 0, 0);
			dwProcessID = SendMessage(hProcessListBox, LB_GETITEMDATA, dwIndex, 0);
			_RunThread(dwProcessID);
			Sleep(200);
			_GetProcessList(hWnd, hProcessListBox, hModuleShowList);
			break;

		case IDC_REFRESH:			
			_GetProcessList(hWnd, hProcessListBox, hModuleShowList);
			break;

		case IDC_PROCESS:
			if (HIWORD(wParam) == LBN_SELCHANGE)
			{
				dwIndex = SendMessage(hProcessListBox, LB_GETCURSEL, 0, 0);
				dwProcessID = SendMessage(hProcessListBox, LB_GETITEMDATA, dwIndex, 0);
				_GetModuleList(hModuleShowList,dwProcessID); //������ʾӳ���ģ��
				EnableWindow(GetDlgItem(hWnd, IDOK), TRUE);
			}
			break;
		}
		break;

	default:
		return FALSE;
	}

	return TRUE;
}




int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hInstance = hInst;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(PROCESSDLG_KILL), NULL, _ProcKillMain, (LPARAM)NULL);
	return 0;
}