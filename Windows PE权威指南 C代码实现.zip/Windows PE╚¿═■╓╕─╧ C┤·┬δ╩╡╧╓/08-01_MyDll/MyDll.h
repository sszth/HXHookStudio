#define EXPORT __declspec (dllexport)


EXPORT void sayHello();
